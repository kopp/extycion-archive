/*****************
 *
 * matrix.h
 *
 * simple matrix class
 * important: Indices of the matrix are conted as in arrays:
 * A = 
 * 	a_00	a_01	a_02
 * 	a_10	a_11	a_12
 *
 *
 * = functions currently supported: =
 *
 * == Programming ==
 * Constructor
 * getter, setter for values
 * getter fro dimensions
 *
 * == Math ==
 * Vectorspace +,-,*
 * Matrix-product
 * transpose
 * inner product (for column-Vectors)
 * p-norm (for column-Vectors)
 * dominant eigenvalue
 * test wether symmetric
 *
 * == Output ==
 * CLI-Output
 * Maxima-Output
 * Octave-Output
 *
 * == Special ==
 * make_jacobi_roataion_matrix: Turns a square matrix into a
 * 	Jacobi-Roattion-Matrix rotationg lines/rows i,j by angle psi
 * setzero sets elements smaller than epsilon to zero
 *
 *
 */

#ifndef MATRIX_H 
#define MATRIX_H

#include<iostream>
#include<iomanip>
#include<cstdlib>
#include<cmath>

#include "zufall.h"

#define MATRIX_H_verbose false

#define getmin(X,Y) ((X<Y)?X:Y)
#define getmax(X,Y) ((X>Y)?X:Y)
#define abs(X) ((X<0)?-X:X)




class Matrix
{
	private: 
		double* daten; 
		unsigned int hoehe;
		unsigned int breite;
		// Matrix ist aus  R(hoehe x breite)

	public:
		//constructor
		Matrix(unsigned int Phoehe, unsigned int Pbreite)
			: hoehe( Phoehe ) , breite( Pbreite ) , daten( new double[Phoehe*Pbreite] ) 
		{
			for( int i = 0; i < Phoehe*Pbreite; i++ )
				daten[i] = 0;
		}
		//~Matrix() { delete[] daten; };

		// ortanisatorisches
		unsigned int get_hoehe() { return hoehe; }
		unsigned int get_breite() { return breite; }
		
		// werte eingeben / auslesen
		void set(const unsigned int n, const unsigned int m, const double value)
		{
			if( (n > hoehe) or (m > breite) ) std::cerr << "Fehler: Matrix hat dim. " << breite << " x " << hoehe << " ; angefragt wurde Element " << n << " x " << m << "\n";
			else daten[ n * breite + m ] = value ;
		}

		/*
		double get(const unsigned int n, const unsigned int m)
		{
			if( (n > hoehe) or (m > breite) ) std::cerr << "Fehler: Matrix hat dim. " << breite << " x " << hoehe << " ; angefragt wurde Element " << n << " x " << m << "\n";
			else return daten[ n*breite + m ];
		}
		*/
		double get(int n, int m)
		{
			if( (n > hoehe) or (m > breite) ) std::cerr << "Fehler: Matrix hat dim. " << breite << " x " << hoehe << " ; angefragt wurde Element " << n << " x " << m << "\n";
			else return daten[ n*breite + m ];
		}
		double operator() (const unsigned int n, const unsigned int m);

		void make_jacobi_roataion_matrix( unsigned int i, unsigned int j, double phi );
		// creates a jacobi-rotation-matrix witch cos(phi) ,..., at (i,j), ...

		

		//// rechnungen... ////
		//
		static Matrix matrixprodukt(Matrix & A, Matrix & B);
		// kann ohne objekt verw. werden
		//
		inline friend Matrix operator+ (Matrix & A, Matrix & B) //addition
		{
			if( (A.get_breite() == B.get_breite()) and (A.get_hoehe() == B.get_hoehe()) )
			{
				Matrix C(A.get_hoehe(), A.get_breite());
				for( int i = 0; i < A.get_hoehe(); i++ )
					for( int j = 0; j < A.get_breite(); j++ )
						C.set(i,j,  A.get(i,j)+B.get(i,j)  );
				return C;
			}
			else std::cerr << "ERROR: Matrices must have same size to add\n";
		}
		inline friend Matrix operator* (double mu, Matrix & A) //produkt mit skalar
		{
			Matrix C( A.get_hoehe() , A.get_breite() );
			for( int i = 0; i < A.get_hoehe(); i++ )
				for( int j = 0; j < A.get_breite(); j++ )
					C.set(i,j, A.get(i,j) * mu );
			return C;
		}
		inline friend Matrix operator-(Matrix & A, Matrix & B) //substraktion
		{
			if( (A.get_breite() == B.get_breite()) and (A.get_hoehe() == B.get_hoehe()) )
			{
				//return A + ( (-1.) * B );
				Matrix C(A.get_hoehe(), A.get_breite());
				for( int i = 0; i < A.get_hoehe(); i++ )
					for( int j = 0; j < A.get_breite(); j++ )
						C.set(i,j,  A.get(i,j)-B.get(i,j)  );
				return C;
			}
			else std::cerr << "ERROR: Matrices must have same size to substract\n";
		}
		//
		static Matrix transponieren(Matrix & A);
		// kann ohne objekt verw. werden
		void transponieren();
		// wird auf das objekt angewandt
		//
		bool test_symmetric();
		//
		static double skalarprodukt( Matrix & A, Matrix & B , double p);
		// 
		double norm(double p); //p-Norm
		void normieren(double p); // in p-Norm normieren
		Matrix normiert(double p); //in p-Norm normiert ausgeben
		//
		// eigenwerte stochastisch ermitteln
		double dominanter_eigenwert( int multiplikationen );
		void eigenwerte(double* liste_ew, int durchlaeufe, int multiplikationen); //sucht n mal nach einem Eigenwert
		// achtung: es ist nicht gesagt, dass n verschiedene gefunden werden!
		// alles stochastische Prozesse!
		// ausgabe: ew werden in ang. Liste geschrieben; liste muss mind laenge durchlaeufe haben!
		//
		void setzero( double epsilon);


		//ausgaben
		void output_cli();
		void output_maxima();
		void output_octave();
};



/*
double Matrix::operator() (const unsigned int n, const unsigned int m)
{
	return *this.get(n,m);
}
*/

void Matrix::make_jacobi_roataion_matrix( unsigned int i, unsigned int j, double phi )
{
	if( breite == hoehe )
	{
		// make 1-Matrix
		for( int k = 0; k < breite; k++ )
			daten[ k * breite + k ] = 1;
		// add ``turning''
		daten[ i * breite + i ] = std::cos(phi);
		daten[ i * breite + j ] = std::sin(phi);
		daten[ j * breite + i ] = - std::sin(phi);
		daten[ j * breite + j ] = std::cos(phi);
	}
	else std::cerr << "Error: The matrix must be square \n";
}



Matrix Matrix::matrixprodukt(Matrix & A, Matrix & B )
{
	if( not ( ( A.get_breite() == B.get_hoehe() ) ) ) 
	{
		std::cerr << "Fehler: Die Matrizen sind nicht geeignet zur Mulitplikation...\n";
		std::exit(3);
	}
	else
	{
		Matrix C( A.get_hoehe() , B.get_breite() );
		for( int i = 0; i < A.get_hoehe(); i++ )
		{
			for( int j = 0; j < B.get_breite(); j++ )
			{
				double summe = 0;
				for( int k = 0; k < A.get_breite(); k++ )
				{
					//summe += A.get((const)i,(const)k)*B.get((const)k,(const)j);
					//summe += A.get(const_cast<unsigned int>(i), const_cast<unsigned int>(k)) * B.get( const_cast<unsigned int>(k),const_cast<unsigned int>(j));
					summe += A.get(i,k)*B.get(k,j);
			if( MATRIX_H_verbose ) std::cout << "Ber A(" << i << "," << k << ") * B(" << k << "," << j << ") = C(" << i << "," << j << ") \n";
				}
				C.set(i,j,summe);
			}
		}

		return C;
	}


}




/*
Matrix operator*(double mu, Matrix & A)
{
	Matrix C( A.get_hoehe() , A.get_breite() );
	for( int i = 0; i < A.get_hoehe(); i++ )
		for( int j = 0; j < A.get_breite(); j++ )
			C.set(i,j, C.get(i,j) * mu );
	return C;
}
Matrix operator-(Matrx & A, Matrix & B)
{
	if( (A.get_breite() == B.get_breite()) and (A.get_hoehe() == B.get_hoehe()) )
	{
		return A + ( (-1.) * B );
	}
	else std::cerr << "ERROR: Matrices have to have same size to substract\n";
}
Matrix operator+(Matrx & A, Matrix & B)
{
	if( (A.get_breite() == B.get_breite()) and (A.get_hoehe() == B.get_hoehe()) )
	{
		Matrix C(A.get_hoehe(), A.get_breite());
		for( int i = 0; i < A.get_hoehe(); i++ )
			for( int j = 0; j < A.get_breite(); j++ )
				C.set(i,j,  A.get(i,j)+B.get(i,j)  );
		return C;
	}
	else std::cerr << "ERROR: Matrices have to have same size to add\n";
}
*/
	



Matrix Matrix::transponieren(Matrix & A)
{
	Matrix At ( A.get_breite() , A.get_hoehe() );
	for( int i = 0; i < A.get_breite(); i++ )
		for( int j = 0; j < A.get_hoehe(); j++ )
			At.set(i,j, A.get(j,i) );
	return At;
}

void Matrix::transponieren()
{
	int foo = breite;
	breite = hoehe;
	hoehe = foo;
	double daten_sicherung[breite*hoehe];
	for( int i = 0; i < breite*hoehe; i++ )
		daten_sicherung[i] = daten[i];
	for( int i = 0; i < breite; i++ )
		for( int j = 0; j < hoehe; j++ )
			daten[ i * breite + j ] = daten_sicherung[ j * hoehe + i ];
}



bool Matrix::test_symmetric()
{
/* Idea:
 * dont test == but \in U_epsilon where epsilon is a paramter to the function
 * with default =0
 */
	if( breite != hoehe ) 
		return false;  //symmetric matrix must be square
	for( int i = 0; i < hoehe; i++ )
		for( int j = 0; j < breite; j++ )
			if( daten[ i * breite + j ] != daten[ j * breite + i ] ) return false;
	return true;
}


double Matrix::skalarprodukt(Matrix & A, Matrix & B, double p = 2)
{
	//via parallelogrammungleichung
	//  4 < a , b > = || x + y ||^2 + || x - y ||^2
	if( (A.get_breite() == 1) and (B.get_breite() == 1) )
	{
		return (  (A+B).norm(p) + (A-B).norm(p)   ) / 4.;
	}
	else std::cerr << "Not yet implemented or impossible\n";
}
					




/* norm alt
 *
double Matrix::norm( Matrix & A )
{
	if( (A.get_breite() == 1) or (A.get_hoehe() ==1) ) //Vektornorm
	{
		if( A.get_breite() == 1) //Spaltenvektor
		{
			double summe = 0;
			for( int i = 0; i < A.get_hoehe(); i++ )
				summe += sqr( A.get(i,0) );
			return std::sqrt( summe );
		}
		else std::cerr << "Not yet implemented\n";
	}
	else std::cerr << "Not yet implemented\n";
}
*/


double Matrix::norm(double p = 2)
{
	if( breite == 1 ) //Spaltenvektor
	{
		double summe = 0;
		for( int i = 0; i < hoehe; i++ )
			summe += std::pow( daten[i*breite + 0 ] , p );
		return pow( summe , 1./p );
	}
	else std::cerr << "Not yet implemented\n";
}

void Matrix::normieren(double p = 2)
{
	double norm = (*this).norm(p);
	for( int i = 0; i < breite * hoehe; i++ )
		daten[i] /= norm;

}

Matrix Matrix::normiert(double p = 2)
{
	//Matrix C = (1./(*this).norm(p)) * (*this) ;
	Matrix C(hoehe, breite);
	double norm = (*this).norm(p);
	for( int i = 0; i < hoehe; i++ 	)
		for( int j = 0; j < breite; j++ )
			C.set(i,j, daten[ i* breite + j ] / norm );
	return C;
}



void Matrix::eigenwerte(double * liste , int durchlaeufe, int multiplikationen = 2)
{
	//FIXME berechnet nur dominanten eigenwert
	double p = 2; // normen
	Matrix v_zufall( breite , 1 );
	Matrix v_nachher( hoehe , 1 );
	for( int durchl = 0; durchl < durchlaeufe; durchl ++ )
	{
		std::srand(durchl);
		//zufallsvektor zufaellig machen
		for( int i = 0; i < breite; i++ )
			//v_zufall.set( i,0,Zufall::zufall() );
			v_zufall.set( i,0,std::rand() );
		//oft auf Matrix anwenden
		v_nachher = matrixprodukt( *this , v_zufall  );
		for( int i = 0; i < multiplikationen; i++ )
			v_nachher = matrixprodukt( *this , v_nachher );
		if( MATRIX_H_verbose ) v_nachher.output_cli();

		//normieren --> nEVn
		v_nachher.normieren(p);
		//nEV anwenden; norm best --> EW
		double ew = (Matrix::matrixprodukt(*this , v_nachher ) ).norm(p);

		liste[durchl] = ew;
	}
}

double Matrix::dominanter_eigenwert(int multiplikationen = 20)
{
	double p = 2; // normen
	Matrix v_zufall( breite , 1 );
	Matrix v_nachher( hoehe , 1 );

	//zufallsvektor zufaellig machen
	for( int i = 0; i < breite; i++ )
		v_zufall.set( i,0,Zufall::zufall() );
	//oft auf Matrix anwenden
	v_nachher = matrixprodukt( *this , v_zufall  );
	for( int i = 0; i < multiplikationen; i++ )
		v_nachher = matrixprodukt( *this , v_nachher );
	if( MATRIX_H_verbose ) v_nachher.output_cli();

	//normieren --> nEVn
	v_nachher.normieren(p);
	//nEV anwenden; norm best --> EW
	double ew = (Matrix::matrixprodukt(*this , v_nachher ) ).norm(p);

	return ew;
}


void Matrix::setzero( double epsilon )
{
	for( int i = 0; i < breite*hoehe; i++ )
		if( abs(daten[i]) < epsilon ) daten[i] = 0;
}


void Matrix::output_cli()
{
/* 
 * prints out matrix on the commandline
 */
	for( int i = 0; i < hoehe; i++ )
	{
		std::cout << " | \t";
		for( int j = 0; j < breite; j++ )
			std::cout <<  daten[ i*breite + j ] << "\t";
		std::cout << " | \n";
	}
}



void Matrix::output_maxima()
{
/* 
 * prints out matrix in a format that maxima can understand
 */
	std::cout << " matrix( ";
	for( int i = 0; i < hoehe; i++ )
	{
		std::cout << " [ ";
		for( int j = 0; j < breite; j++ )
			std::cout <<  daten[ i*breite + j ] << ((j==(breite-1))?" ":" , ");
		std::cout << " ]" << ((i==(hoehe-1))?" ":" , ");
	}
	std::cout << " ) \n";
}

void Matrix::output_octave()
{
/* 
 * prints out matrix in a format that maxima can understand
 */
	std::cout << " [ ";
	for( int i = 0; i < hoehe; i++ )
	{
		for( int j = 0; j < breite; j++ )
			std::cout <<  daten[ i*breite + j ] << " ";
		std::cout << ((i==(hoehe-1))?" ":" ; ");
	}
	std::cout << " ] \n";
}










#endif
