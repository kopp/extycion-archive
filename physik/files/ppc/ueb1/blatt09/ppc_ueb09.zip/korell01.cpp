#include<iostream>
#include<cmath>


double f(double x)
{
	// 1.
	return ( (20 <= x) and (x <= 25) ) ? 1 : 0 ;
	// 2.
	//return (int(x) % 20 ==0 ? 1 : 0 );
}

double g(double x)
{
	// 1.
	return ( (90 <= x) and (x <= 95) ) ? 1 : 0 ;
	// 2.
	//return ( (0 <= x) and (x <= 10 ) ) ? ( (x<=5)?1:10-x ) : 0 ;
}

double periodisch_fortsetzen(double (*funktion)(double) , double periode , double xi)
{
/* setzt funktion periodisch mit periode fort und wertet bei xi aus.
* die Auswertung geschiet also im Endeffekt fuer x in [0,periode].
*/
	int perioden_zurucksetzen = 0;
	if( xi > periode ) //muss zurueckgesetzt werden	
		perioden_zurucksetzen = xi / periode;
	return ( (*funktion)( xi - perioden_zurucksetzen * periode ) );
}


/*
double h(double x)
{
	return std::sin(x);
}
*/
		
	



int main()
{
	int N = 100; //anzahl stuetzstellen fuer berechnung von c(tau)
	/* teste periodisch_fortsetzen:
	for( double x = 0; x < 5; x += 0.03 )
		std::cout << x << "\t" << periodisch_fortsetzen( h , 1. , x ) << "\n";
	*/

	// parameter fuer tau
	double a = -150;
	double b = 150;
	int N_tau  = 3000; //anzahl stuetzstellen fuer ausgabe von c(tau)
	double deltatau = (b-a)/N_tau;


	for( double tau = a; tau < b; tau += deltatau )
	{
		double summe = 0;
		for( int t = 0; t < N; t++ )
			summe += periodisch_fortsetzen(f,N,(t+tau)) * g(t) ;
		double c_tau = summe / N;

		//ausgabe
		std::cout << tau << "\t" << c_tau << "\n";
	}
		

}


