#include<iostream>
#include "matrix.h"
#include <cmath>


int main()
{
	/*
	Matrix A(5,5);
	std::cout << "Matrix A: \n";
	A.output_cli();


	A.make_jacobi_roataion_matrix( 1 , 3 , M_PI/4.0 );
	std::cout << "Jacobi-Rotation 2 , 2 , pi/2 : \n";
	A.output_cli();
	*/


	Matrix C(3,3);
	std::cout << "Matrix C: \n";
	C.set(2,1, 4.214);
	C.set(1,2, 4.214);
	C.set(2,2, 3.1);
	C.set(1,1,1.4);
	C.output_cli();
	if( C.test_symmetric() ) std::cout << "C ist symmetrisch\n";
	else std::cout << "C ist _nicht_ symmetrisch\n";

	Matrix foo(3,3);
	foo.make_jacobi_roataion_matrix(  2,1, 0.5 * std::atan( 2. * C.get(2,1) / (C.get(1,1)-C.get(2,2)) )  );
	Matrix bar = Matrix::matrixprodukt( C , foo );
	foo.transponieren();
	bar = Matrix::matrixprodukt( foo , bar );
	bar.output_cli();




}
