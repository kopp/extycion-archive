/******************
 *
 * jacobi01.cpp
 *
 * depends on matrix.h
 *
 * Michael Kopp
 *
 * uses Jacobi-Method to determine Eigenvectors and Eigenvalues of a symmetric
 * matrix.
 *
 * All Parameters (such as accurancy, Iterations, the Matrix itself) have to be
 * entered in the source directly.
 *
 * Output:
 * Matrix A,
 * Transformation Matrix Q
 * Transformed Matrix Qt . A . Q
 * Transformed matrix with small values set to zero
 *
 * if JACOBI01_CPP_verbose is set to true verbose output is given
 *
 *                                                          ******************/

#include<iostream>
#include<cmath>
#include "matrix.h"
//#include "zufall.h"


#define JACOBI01_CPP_verbose false

int main()
{

	//// numerical parameters ////
	double epsilon = 1e-10; //values smaller than this are set to zero
	bool use_setzero_during_evaluation = true; //if true in each iteration
			//the setzero()-Command is applied to matrix A_tr
	int iteration_max = 10; //number of iterations -- 10 normally suffice
	/*TIP
	 * if output does not make sense set epsilon smaller and 
	 * use_setzero_during_evaluation=false
	 */ 


	// construct symmetric Matrix A
	int dim = 5;
	Matrix A(dim,dim);
	/* zufallsmatrix -- uncomment #include "zufall.h" !
	for( int i = 0; i < dim; i++ )
		for( int j = i; j < dim; j++ )
		{
			double foo = Zufall::zufall();
			A.set( i,j, foo );
			A.set( j,i, foo );
		}
	*/
	A.set(0,0,2.);
	A.set(1,1,1.);
	A.set(2,2,4.);
	A.set(3,3,1.2);
	A.set(4,4,1.4);
	A.set(0,1,4.1); A.set(1,0,4.1);
	A.set(0,2,5.1); A.set(2,0,5.1);
	A.set(0,3,7.1); A.set(3,0,7.1);
	A.set(0,4,2.1); A.set(4,0,2.1);
	A.set(1,2,2.1); A.set(2,1,2.1);
	A.set(3,4,2.1); A.set(4,3,2.1);
	A.set(2,3,8.1); A.set(3,2,8.1);
	A.set(2,4,5.0); A.set(4,2,5.0);
	if( A.test_symmetric() )
	{
		std::cout << "Created symmetric Matrix A: \n";
		A.output_cli();
		A.output_maxima();
		A.output_octave();
	}
	else
	{
		std::cout << "FEHLER: Matrix must be symmetric\n";
		return 1;
	}


	// begin with 1-Matrix as transformation
	Matrix transformation(dim,dim);
	for( int i = 0; i < dim; i++ )
		transformation.set(i,i,1.);

	Matrix A_tr = A; // the matrix to be translated -- A is held as copy
	for( int iteration_nr = 0; iteration_nr < iteration_max; iteration_nr++ )
	{
		if( JACOBI01_CPP_verbose ) std::cout << "Starting iteration nr " << iteration_nr << " ... \n";
		//iteration over off-diagonal-elements
		for( int i = 0; i < dim; i++ )
			for( int j = i+1; j < dim; j++ )
			{
				if( JACOBI01_CPP_verbose ) std::cout << "   Element " << i << " , " << j << "\n";
				// determine angle
				// http://www.mia.uni-saarland.de/Teaching/MFI07/kap51.pdf
				double phi = 0.5 * std::atan ( 2. * A_tr.get(i,j) / (A_tr.get(j,j) - A_tr.get(i,i)) );
				// construct jacobi-rotatong-matrix
				Matrix foo(dim,dim);
				foo.make_jacobi_roataion_matrix(i,j,phi);
				// append to transformation-matrix
				transformation = Matrix::matrixprodukt( transformation , foo );
				// Apply transformation to A_tr
				Matrix bar = Matrix::matrixprodukt( A_tr , foo );
				foo.transponieren();
				A_tr = Matrix::matrixprodukt( foo , bar );
				if( use_setzero_during_evaluation ) A_tr.setzero(epsilon);
				if( JACOBI01_CPP_verbose )
				{
					std::cout << "A becomes \n";
					A_tr.output_cli();
				}

					
			}
		if( JACOBI01_CPP_verbose ) std::cout << " Iteration Nr " << iteration_nr << " done \n";
	}

	std::cout << "Transformation-Matrix is [COLUMNS ARE EIGENVECTORS] \n";
	transformation.output_cli();

	std::cout << "A is transformed to \n";
	Matrix bar = Matrix::matrixprodukt( A , transformation );  // bar = A . T
	transformation.transponieren();
	Matrix A_transformiert = Matrix::matrixprodukt( transformation , bar ); // A' = Tt . bar = Tt . A . T
	A_transformiert.output_cli();
	std::cout << "With accurancy of " << epsilon << " this is equal to [NUMBERS ARE EIGENVALUES] \n";
	A_transformiert.setzero(epsilon);
	A_transformiert.output_cli();


}
