#ifndef RANDOM_H
#define RANDOM_H

#include<cstdlib>


class Zufall
{

	private:
	public:

static double zufall() //with static the function can be called without an object of Zufall
{
	return double(std::rand())/RAND_MAX;
}

};




#endif
