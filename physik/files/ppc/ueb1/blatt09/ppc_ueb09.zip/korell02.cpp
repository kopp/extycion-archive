/**************
*
* korell02.cpp
*
* bestimmt die korellation zweier externer Datensaetze
* basiert auf korell01.cpp
* ausgabe:
*   [tau] [kor] 
*
*                                                         ********************/

#include<iostream>
#include<cmath>
#include<fstream>


// daten aus dateien sollen global verfuegbar sein
// nicht schoen ... tut was man will ;-)
double *daten1;
double *daten2;



double f(double x)
{
	// 1.
	// return ( (20 <= x) and (x <= 25) ) ? 1 : 0 ;
	// 2.
	//return (int(x) % 20 ==0 ? 1 : 0 );
	// 3. eingabe aus dateien
	return daten1[ int(x) ];
}

double g(double x)
{
	// 1.
	// return ( (90 <= x) and (x <= 95) ) ? 1 : 0 ;
	// 2.
	//return ( (0 <= x) and (x <= 10 ) ) ? ( (x<=5)?1:10-x ) : 0 ;
	// 3. eingabe aus dateien
	return daten2[ int(x) ];
}

double periodisch_fortsetzen(double (*funktion)(double) , double periode , double xi)
{
/* setzt funktion periodisch mit periode fort und wertet bei xi aus.
* die Auswertung geschiet also im Endeffekt fuer x in [0,periode].
*/
	int perioden_zurucksetzen = 0;
	if( xi > periode ) //muss zurueckgesetzt werden	
		perioden_zurucksetzen = xi / periode;
	return ( (*funktion)( xi - perioden_zurucksetzen * periode ) );
}


/*
double h(double x)
{
	return std::sin(x);
}
*/
		
	



int main()
{
	int N = 10000; //anzahl stuetzstellen fuer berechnung von c(tau)
	/* teste periodisch_fortsetzen:
	for( double x = 0; x < 5; x += 0.03 )
		std::cout << x << "\t" << periodisch_fortsetzen( h , 1. , x ) << "\n";
	*/

	// parameter fuer tau
	double a = 0.;
	double b = double(N);
	int N_tau  = 10 * N; //anzahl stuetzstellen fuer ausgabe von c(tau)
	double deltatau = (b-a)/N_tau;


	// daten einlesen
	daten1 = new double[N];
	daten2 = new double[N];
	char* eingabedatei1 = (char*)"rauschen.dat";
	char* eingabedatei2 = (char*)"rauschen.dat";

	std::fstream eingabe1 ( eingabedatei1 );
	if( not eingabe1.good() ) { std::cerr << "Fehler beim Oeffnen von 1. Datei" ; return 11 ; }

	std::fstream eingabe2 ( eingabedatei2 );
	if( not eingabe2.good() ) { std::cerr << "Fehler beim Oeffnen von 2. Datei" ; return 12 ; }

	double junk;
	for( int i = 0; i < N; i++ )
	{
		eingabe1 >> junk >> daten1[i];
		eingabe2 >> junk >> daten2[i];
	}
	eingabe1.close();
	eingabe2.close();
		




	for( double tau = a; tau < b; tau += deltatau )
	{
		double summe = 0;
		for( int t = 0; t < N; t++ )
			summe += periodisch_fortsetzen(f,N,(t+tau)) * g(t) ;
		double c_tau = summe / N;

		//ausgabe
		std::cout << tau << "\t" << c_tau << "\n";
	}
		

}


