/*
 * sphere.cpp
 * bases on pi.cpp
 *
 * Michael Kopp
 *
 * compute the volume of a n-dim spphere using MC methods
 *
 * In each of the c cycles pi is computed once using N random numbers
 *
 * compile:
 *   $ g++ `gsl-config --libs` sphere.cpp
 *
 *
 * usage:
 * -N     number of random numbers
 * -c     number of cycles
 */

#include<cstdio>
#include<gsl/gsl_rng.h>
#include<cstring>
using std::strcmp ;
#include<cstdlib>
using std::atof ;
#include<cmath>
using std::sqrt ;
using std::pow ;

inline double sqr( const double x ) 
{
	return x * x ;
}

// distance to ordo in dimension d
inline double distance( double x[] , const int d)
{
	double m = 0;
	for( int i = 0; i < d; i++ )
		m += sqr( x[i] ) ;
	return sqrt( m ) ;
}

int main(int argc , char* argv[] )
{
	// // parameters // //
	// ration l/d
	double ld = 1 ;
	// # of random numbers
	int N = 1000 ;
	// # of cycles
	int c = 10 ;
	// Dimension
	int d = 2 ;

	
	// // initialize generator // //
	gsl_rng_env_setup() ; // read environment variables
	const gsl_rng_type * typ = gsl_rng_default ;
	gsl_rng * generator = gsl_rng_alloc( typ ) ;

	// // command line arguments // //
	for( char** pointer = argv ; *pointer ; pointer++ )
	{
		// if( std::strcmp( *pointer , "-ld" ) == 0 ) { ld = atof( *(++pointer) ); }
		if( std::strcmp( *pointer , "-N" ) == 0 ) { N = atoi( *(++pointer) ); }
		if( std::strcmp( *pointer , "-c" ) == 0 ) { c = atoi( *(++pointer) ); }
		if( std::strcmp( *pointer , "-d" ) == 0 ) { d = atoi( *(++pointer) ); }
	}
	// validy check
	if( c < 1 ) { printf("make c > 0\n" ) ; std::exit(2) ; }
	if( d < 2 ) { printf("make d > 1\n" ) ; std::exit(2) ; }

	// // volume -- store each value in this array // //
	double* volume = new double [ c ] ; 

	// // loop // //
	for( int ic = 0 ; ic < c; ic++ )
	{
		// counter
		int incircle = 0 ;
		for( int i = 0 ; i < N ; i++ )
		{
			// compute random position in space
			double position[d] ;
			for( int j = 0 ; j < d ; j++ )
				position[j] = gsl_rng_uniform( generator ) ;
			if( distance( position , d ) < 1. ) incircle++ ;
		}
		// estimate volume
		volume[ ic ] = pow(2,d) * incircle / N ;
		// IMPORTANT: The pos(2,d) factor is important since
		// gsl_rng_uniform only gives random numbers in [0,1), thus of
		// each coordinate only the half is used.
	}

	// // analysis // //
	// mean value
	double volume_mean = 0;
	for( int i = 0; i < c ; i++ )
		volume_mean += volume[i] ;
	volume_mean /= c;
	// Variance of the volume
	double var_f = 0;
	for( int i = 0; i < c; i++ )
		var_f += sqr( volume[i] - volume_mean ) ;
	var_f /= c;
	
	

	printf( "The result after %8d circles with %8d iterations is: %.8f\nthe variance of the volumess is %.3e \n" , c, N , volume_mean , var_f ) ;


	// // free RNG // //
	gsl_rng_free( generator ) ;

}
