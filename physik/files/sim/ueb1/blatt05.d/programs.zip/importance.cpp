/*
 * importance.cpp
 *
 * Michael Kopp
 *
 * Integrate a function using Monte Carlo's Importance Sampling method
 *
 * usage:
 * -N    No of random numbers per cycle
 * -c    No of cycles
 * -b    Upper boundary -- lower one is 0
 *
 */

#include<cstdio>
using std::printf ;
#include<cmath>
using std::exp ;
using std::log ;
#include<cstring>
#include<cstdlib>
using std::atoi ;
using std::atof ;
#include<gsl/gsl_rng.h>
#include<gsl/gsl_statistics_double.h>


inline double f( const double x )
{
	printf("f") ;
	return exp(-x*x/2. ) ;
}

inline double h( const double x , const double _A = 0 , const double _l = 0 )
{
        // initialize h(x) by running it once with the correct A,l
        static double A = _A ; 
        static double l = _l ;
        // actual function
        return A * exp( -x / l ) ;
}
inline double Hinv( const double y , const double _A = 0 , const double _l = 0 )
{
        static double A = _A ;
        static double l = _l ;
        return -l * log( 1- y / (A*l) ) ;
}




int main(int argc , char* argv[] )
{

	// // parameter // //
	// # of random numbers
	int N = 100 ;
	// # of cycles
	int c = 10 ;
	// integration range
	double a = 0 ;
	double b = 2 ;

	// // initialize GSL RNG // //
	gsl_rng_env_setup() ;
	const gsl_rng_type * typ = gsl_rng_default ;
	gsl_rng * generator = gsl_rng_alloc( typ ) ;

	// // command line arguments // //
        for( char** pointer = argv ; *pointer ; pointer++ )
        {
                if( std::strcmp( *pointer , "-N" ) == 0 ) { N = atoi( *(++pointer) ); }
                if( std::strcmp( *pointer , "-c" ) == 0 ) { c = atoi( *(++pointer) ); }
                if( std::strcmp( *pointer , "-b" ) == 0 ) { b = atof( *(++pointer) ); }
        }


	// // store integrals for each loop
	double * i_std = new double[ c ] ;
	double * i_imp = new double[ c ] ;

	// // loop cycles // // 
	for( int ic = 0 ; ic < c ; ic++ )
	{

		// // classical monte carlo // //
		double cmc = 0 ;
		for( int i= 0 ; i < N ; i++ )
			cmc += f( a + (b-a) * gsl_rng_uniform( generator ) ) ;
		cmc /= N ;
		cmc *= (b-a) ;
		i_std[ ic ] = cmc ;


		// // importance sampling // //
		// characteristic length
		double l = 1. ;
		// chose A so that H(b) = 1:
		double A = (1/l)/(1.-exp(-b/l)) ;
		// initialize h and Hinv:
		h(0,A,l) ;
		Hinv(0,A,l) ;
		//
		double ismc = 0 ;
		for( int i = 0 ; i < N ; i++ )
		{
			// as xi is the new random variable, compute x = x(xi)
			double x = Hinv( gsl_rng_uniform( generator ) ) ;
			ismc += f(x)/h(x) ;
		}
		ismc /= N ;
		// no rescaling necessary since xi \in [0,1], so factor would be (1-0) = 1.
		i_imp[ ic ] = ismc ;

	}

	// // evaluation // //
	double mean_std =  gsl_stats_mean (i_std, 1, c ) ;
	double vari_std =  gsl_stats_variance (i_std, 1, c ) ;
	double mean_imp =  gsl_stats_mean (i_imp, 1, c ) ;
	double vari_imp =  gsl_stats_variance (i_imp, 1, c ) ;

	// // output // //
	printf( "Integrate exp(-x^2/2) over [0,%5.4f] using Monte Carlo Methods\n" , b ) ;
	printf( "used %10d random numbers for each of the %6d cycles\n" , N , c ) ;
	printf( "Standard MC approx.:            %.6e +/- %.6e \nImportance sampling MC approx.: %.6e +/- %.6e \n" , mean_std , vari_std , mean_imp , vari_imp ) ;


	gsl_rng_free( generator ) ;

}

