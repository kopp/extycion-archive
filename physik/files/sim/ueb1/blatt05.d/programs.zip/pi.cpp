/*
 * pi.cpp
 *
 * Michael Kopp
 *
 * compute pi using Monte Carlo integration
 *
 * In each of the c cycles pi is computed once using N random numbers
 *
 * compile:
 *   $ g++ `gsl-config --libs` pi.cpp
 *
 *
 * usage:
 * -ld    ratio l/d
 * -N     number of random numbers
 * -c     number of cycles
 */

#include<cstdio>
#include<gsl/gsl_rng.h>
#include<cstring>
using std::strcmp ;
#include<cstdlib>
using std::atof ;
#include<cmath>

inline double sqr( const double x ) 
{
	return x * x ;
}

int main(int argc , char* argv[] )
{
	// // parameters // //
	// ration l/d
	double ld = 1 ;
	// # of random numbers
	int N = 1000 ;
	// # of cycles
	int c = 10 ;

	
	// // initialize generator // //
	gsl_rng_env_setup() ; // read environment variables
	const gsl_rng_type * typ = gsl_rng_default ;
	gsl_rng * generator = gsl_rng_alloc( typ ) ;

	// // command line arguments // //
	for( char** pointer = argv ; *pointer ; pointer++ )
	{
		if( std::strcmp( *pointer , "-ld" ) == 0 ) { ld = atof( *(++pointer) ); }
		if( std::strcmp( *pointer , "-N" ) == 0 ) { N = atoi( *(++pointer) ); }
		if( std::strcmp( *pointer , "-c" ) == 0 ) { c = atoi( *(++pointer) ); }
	}
	// validy check
	if( ld < 1 ) { printf("make ld >= 1\n" ) ; std::exit(1) ; }
	if( c < 1 ) { printf("make c > 0\n" ) ; std::exit(2) ; }

	// // pi -- store each value in this array // //
	double* pi = new double [ c ] ; 

	// // loop // //
	for( int ic = 0 ; ic < c; ic++ )
	{
		// counter
		int incircle = 0 ;
		for( int i = 0 ; i < N ; i++ )
			if( sqr( ld * gsl_rng_uniform( generator ) ) + sqr( ld * gsl_rng_uniform( generator ) ) < 1. ) incircle++ ;
		// IMPORTANT: in this inequality, use r^2 on the right hand side!
		// estimate pi
		pi[ ic ] = 4. * sqr(ld) * incircle / N ;
	}

	// // analysis // //
	// mean value
	double pi_mean = 0;
	for( int i = 0; i < c ; i++ )
		pi_mean += pi[i] ;
	pi_mean /= c;
	// Variance of the pi
	double var_f = 0;
	for( int i = 0; i < c; i++ )
		var_f += sqr( pi[i] - pi_mean ) ;
	var_f /= c;
	
	

	printf( "The result after %8d circles with %8d iterations is: %.8f\nrelative error is %.3e , the variance of the pis is %.3e \n" , c, N , pi_mean , (pi_mean-M_PI)/M_PI , var_f ) ;


	// // free RNG // //
	gsl_rng_free( generator ) ;

}
