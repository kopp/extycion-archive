/* * rw1d.cpp
 * derived from pi.cpp
 *
 * Michael Kopp
 *
 * perform random walks in one dimension on a discrete `lattice'
 *
 * In each of the c cycles, a RW with N steps is performed, after all cycles,
 * the mean distance traveled, the mean of it's square and the variance of the
 * distances will be computed
 *
 * compile:
 *   $ g++ `gsl-config --libs` rw1d.cpp
 * or to get some more efficiency out of it
 *   $ g++ -O2 -DHAVE_INLINE `gsl-config --libs` -o rw1d rw1d.cpp
 *
 * usage:
 * -N     number of random numbers
 * -c     number of cycles
 * -p     propability to go right 
 * -b     number of bins (0 for no histo)
 *
 *
 */

#include<cstdio>
#include<gsl/gsl_rng.h>
#include<cstring>
using std::strcmp ;
#include<cstdlib>
using std::atof ;
#include<cmath>
#include<gsl/gsl_statistics_double.h>
#include<gsl/gsl_histogram.h>

inline double sqr( const double x ) 
{
	return x * x ;
}

int main(int argc , char* argv[] )
{
	// // parameters // //
	// # of random numbers
	int N = 1000 ;
	// # of cycles
	int c = 10 ;
	// propability to go right
	double p = 0.5 ;
	// # of bins
	int bins = 20 ;

	
	// // initialize generator // //
	gsl_rng_env_setup() ; // read environment variables
	const gsl_rng_type * typ = gsl_rng_default ;
	gsl_rng * generator = gsl_rng_alloc( typ ) ;

	// // command line arguments // //
	for( char** pointer = argv ; *pointer ; pointer++ )
	{
		if( std::strcmp( *pointer , "-N" ) == 0 ) { N = atoi( *(++pointer) ); }
		if( std::strcmp( *pointer , "-c" ) == 0 ) { c = atoi( *(++pointer) ); }
		if( std::strcmp( *pointer , "-p" ) == 0 ) { p = atof( *(++pointer) ); }
		if( std::strcmp( *pointer , "-b" ) == 0 ) { bins = atoi( *(++pointer) ); }
	}
	// validy check
	if( c < 1 ) { printf("make c > 0\n" ) ; std::exit(2) ; }
	if( p < 0 or p >= 1 ) { printf("make 0 < p < 1\n" ) ; std::exit(3) ; }

	// store final position here:
	double*  endpos = new double [ c ] ;
	double*  endpos2 = new double [ c ] ;

	// // loop // //
	// cycles
	for( int ic = 0 ; ic < c ; ic ++ )
	{
		int position = 0 ;
		// steps
		for( int j = 0 ; j < N ; j++ )
			if( gsl_rng_uniform( generator ) < p ) position -- ;
			else position ++ ;
		endpos[ ic ] = position ;
		endpos2[ ic ] = position*position ;
	}


	// // evaluate the data // //
	// < r >
	double mean = gsl_stats_mean (endpos, 1, c ) ;
	// sum ( r_i - \bar r ) / (N-1)
	double mean_sd = gsl_stats_variance_m (endpos , 1 , c, mean ) ;
	// < r^2 >
	// double mean_2 = gsl_stats_variance_m (endpos, 1, c , 0) * (c-1) ; //should actuallo work...
	double mean_2 = gsl_stats_mean( endpos2 , 1 , c ) ;
	// output these
	printf( "#After %8d cycles of %8d walks with p = %.5f:\n# the mean endpos is %.7e +/- %.6e\n# the mean of the squared endpos is %.7e \n" , c , N , p ,mean , mean_sd , mean_2  ) ;

	// histogramm
	if( bins > 0 )
	{
		gsl_histogram * histo = gsl_histogram_alloc( bins ) ;
		gsl_histogram_set_ranges_uniform( histo , gsl_stats_min( endpos , 1 , c ) , gsl_stats_max( endpos ,1 , c ) ) ;
		for( int i = 0 ; i < c ; i ++ )
			gsl_histogram_increment( histo , endpos[i] ) ;		

		// output histo
		FILE * histooutput = std::fopen( "histogramm.data" , "w" ) ;
		gsl_histogram_fprintf (histooutput, histo, "%.10e" , "%f" ) ; 
		std::fclose( histooutput ) ;

		// free
		gsl_histogram_free( histo ) ;
	}



	


	// // free stuff // //
	gsl_rng_free( generator ) ;
	delete[] endpos ;
	delete[] endpos2 ;

}
