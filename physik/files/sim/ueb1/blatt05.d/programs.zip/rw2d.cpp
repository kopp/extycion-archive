/*
 * rw2d.cpp
 *
 * Michael Kopp
 *
 * Performs a random walk in two dimensions
 * The walks are self avoiding if desired.
 *
 * usage: 
 * -N   length of rw
 * -c   number of cycles
 * -s   activate saw (self avoiding random walk)
 * -on  activate numeric output
 * -os  activate symbolic output
 * -t   output trajectories in file `trajectory.data'
 *
 */

#include<cstdio>
#include"board.h"
#include<gsl/gsl_rng.h>
#include<cstdlib>
using std::atoi ;
#include<cstring>
using std::strcmp ;
#include<cmath>
using std::sqrt ;
#include<gsl/gsl_statistics_double.h>
#include<iostream>

inline double sqr( const double x )
{
	return x * x ;
}

int main( int argc , char* argv[] ) 
{
	// // parameters // //
	// # of steps -- i.e. random numbers
	// the board will have the size (2N+1)x(2N+1)
	int N = 10 ;
	// # of cycles
	int c = 10 ;
	// SAW -- self avoidance walk?
	bool saw = false ;
	// output
	char output = 'x' ; // x: none
	// trajectories
	bool traj = false ;

        // // initialize generator // //
        gsl_rng_env_setup() ; // read environment variables
        const gsl_rng_type * typ = gsl_rng_default ;
        gsl_rng * generator = gsl_rng_alloc( typ ) ;


	// // command line arguments // //
        for( char** pointer = argv ; *pointer ; pointer++ )
        {
                if( std::strcmp( *pointer , "-N" ) == 0 ) { N = atoi( *(++pointer) ); }
                if( std::strcmp( *pointer , "-c" ) == 0 ) { c = atoi( *(++pointer) ); }
                if( std::strcmp( *pointer , "-s" ) == 0 ) { saw = true ; } 
                if( std::strcmp( *pointer , "-os" ) == 0 ) { output = 's'; }
                if( std::strcmp( *pointer , "-on" ) == 0 ) { output = 'n'; }
                if( std::strcmp( *pointer , "-t" ) == 0 ) { traj  = true ; } 
        }


	// final positions
	double * final_x = new double[ c ] ;
	double * final_y = new double[ c ] ;
	// final distance squared
	double * final_d2 = new double[ c ] ;
	// final distance
	double * final_d = new double[ c ] ;
	// number of contacts
	double * contact = new double[ c ] ; // how often does the RW violate saw?
	// number of aborted walks due to full neighbours
	double * full = new double [ c ] ;
	// mean length of the aborted RW
	double full_length = 0 ;
	int no_full_length = 0 ;
	for( int i = 0 ; i < c ; i++ )
	{
		final_x[i] = 0 ;
		final_y[i] = 0 ;
		final_d2[i] = 0 ;
		final_d[i] = 0 ;
		contact[i] = 0 ;
		full[i] = 0 ;
	}


	// trajectory
	/*
	if( traj )
	{
		double *** traj_data  = new double**[ c ] ;
		for( int i = 0 ; i < c ; i++ )
		{
			traj_data[i] = new double*[ N ] ;
			for( int j = 0 ; j < N ; j++ )
				(traj_data[i])[j] = new double[ 3 ] ;
		}
	}
	*/
	FILE * trajectoryoutput ;
	if( traj ) trajectoryoutput = std::fopen( "trajectory.data" , "w" ) ;
	

	// // loops // //
	for( int ic = 0 ; ic < c ; ic ++ )
	{
		// how many walks must be aborted?
		int fullneighbours = 0 ;

		// baaad gogo mark ... I know...
begin_cycle_loop: 
		// output
		if( traj ) std::fprintf( trajectoryoutput , "# Starting RW no %d\n\n" , ic ) ;

		// empty board
		board walk( N ) ;

		// 0th step
		int current_x = 0 ;
		int current_y = 0 ;
		walk.increment( current_x , current_y ) ;

		// their mean number of steps
		// double mean_aborted_step_length = 0; 

		// start the walk
		for( int i = 0 ; i < N ; i++ )
		{
			// // check whether it's possible to move anywhere (only saw)
			if( saw )
			{
				if( 
					( !  walk.isempty(current_x+1,current_y) ) and
					( !  walk.isempty(current_x-1,current_y) ) and
					( !  walk.isempty(current_x,current_y+1) ) and
					( !  walk.isempty(current_x,current_y-1) )
				) // every neighbout is full...
				{
					// std::cerr << "every neighbour is full...\n" ;
					if( traj ) std::fprintf( trajectoryoutput , "# RW no %d finished too early\n\n" , ic ) ;
					// compute new mean value:
					// previously the mean was the mean
					// over fullneighbours lengths so by
					// multiplying it with fullneighbours,
					// that's the absolute sum of
					// aborted_steps. The length of this
					// particluar walk is added and then
					// divided by the amount of lengths...
					// mean_aborted_step_length = ( mean_aborted_step_length * fullneighbours + i )/(fullneighbours +1 ) ;
					full_length = ( full_length * no_full_length + i )/( no_full_length +1 ) ;
					no_full_length++ ;

					fullneighbours++ ;
					goto begin_cycle_loop ;
				}
			}
			// random directory:
			int dx = 0 ; 
			int dy = 0 ;
			if( gsl_rng_uniform( generator ) < 0.5 ) // x
			{
				dy = 0 ;
				if( gsl_rng_uniform( generator ) < 0.5 ) // left
					dx = -1 ;
				else // right
					dx = 1 ;
			}
			else // y
			{
				dx = 0 ;
				if( gsl_rng_uniform( generator ) < 0.5 ) // down
					dy = -1 ;
				else // up
					dy = 1 ;
			}

			// if saw check if next place is free
			if( ( saw == false) or ( saw == true and walk.isempty( current_x+dx , current_y+dy ) ) )
			{
				int intersects = walk.increment( current_x+dx ,current_y+dy ) ;
				// intersects is the number, how often this specific place
				// has already been `visited'
				if( intersects > 1 ) contact[ic]++ ;

			}
			else
			{
				// this means that the desired place was already visited
				// try again -- draw a new directory...
				i-- ;
				continue ;
			}

			// actually move 
			current_x += dx ;
			current_y += dy ;

			// output
			if( traj ) std::fprintf( trajectoryoutput , "%10d %10d %10d %10d \n" , ic , i , current_x , current_y ) ;
		}

		switch( output )
		{
			case 'n' : walk.printboard_cli(  ) ; break ;
			case 's' : walk.printboard_cli( true ) ; break ;
		}

		// store final points etc
		final_x[ic] = current_x ;
		final_y[ic] = current_y ;
		final_d2[ic] = sqr(current_x) + sqr(current_y) ;
		final_d[ic] = sqrt( final_d2[ic] ) ;
		full[ic] = fullneighbours ;
		// length_full[ic] = mean_aborted_step_length ;
		// printf( "%d\n" , fullneighbours ) ;
	}

	if( traj ) std::fclose( trajectoryoutput ) ;


	// // evaluation // //
	// -- final start-end distance:
	// mean
	double mean_d = gsl_stats_mean( final_d , 1 , c ) ;
	// variance
	double vari_d = gsl_stats_variance( final_d , 1 , c ) ;
	// -- final squared start-end distance:
	// mean
	double mean_d2 = gsl_stats_mean( final_d2 , 1 , c ) ;
	// variance
	double vari_d2 = gsl_stats_variance( final_d2 , 1 , c ) ;
	// -- contact
	// numbers of walks with contact
	int has_contact = 0 ;
	for( int i = 0 ; i < c ; i++ )
		if( contact[i] != 0 ) has_contact++ ;
	// mean number of contacts
	double mean_contact = gsl_stats_mean( contact , 1 , c ) ;
	// variance
	double vari_contact = gsl_stats_variance( contact , 1 , c ) ;
	// -- full
	double mean_full = gsl_stats_mean( full , 1 , c ) ;
	// mean length
	// double mean_aborted_leng = gsl_stats_mean( length_full , 1 , c ) ;
	
	
	// // output // //
	printf( "Conducted %d random walks with %d steps each\n" , c , N ) ;
	printf( "Mean final distance start--end: %.6f +/- %.6e\n" , mean_d , vari_d ) ;
	printf( "Mean squared final distance start--end: %.6f +/- %.6e\n" , mean_d2 , vari_d2 ) ;
	printf( "%d random walks had self contact (ratio %f)\n" , has_contact , has_contact * 1. / c ) ;
	printf( "On average (averaged over _all_ walks) it were %.6f +/- %.6e contacts\n" , mean_contact , vari_contact ) ;
	printf( "Average %.6f saw could not finish as all neighbouring spaces were already occupied\n" , mean_full ) ;
	printf( "They had a mean length of %.6e \n" , full_length ) ;
	

}

