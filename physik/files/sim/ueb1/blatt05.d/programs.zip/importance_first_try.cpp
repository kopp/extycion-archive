#include<cstdio>
using std::printf ;
#include<cmath>
using std::sin ;
using std::exp ;
using std::log ;
#include<cstdlib>


inline double f(const double x )
{
	return 1.+sin(x)/x ;
}
inline double h( const double x , const double _A = 0 , const double _l = 0 )
{
	// initialize h(x) by running it once with the correct A,l
	static double A = _A ; 
	static double l = _l ;
	// actual function
	return A * exp( -x / l ) ;
}
inline double Hinv( const double y , const double _A = 0 , const double _l = 0 )
{
	static double A = _A ;
	static double l = _l ;
	return -l * log( 1- y / (A*l) ) ;
}

inline double zufall( const double a , const double b )
{
	return (b-a)* std::rand() / RAND_MAX ;
}


int main()
{

	int N = 10000;

	// // classical monte carlo // //
	double mean = 0 ;
	for( int i = 0 ; i < N ; i++ )
	{
		mean += f( zufall( 0 , 1 ) ) ;
	}
	mean /= N ;
	printf( "# classical: %.6f\n" , mean ) ;

	// // importance sampling // //
	// use h(x) = A exp(-x/l) for importance sampling, with A a normation
	// constant.
	// To get new distribution:
	//    H(x) = int_0^x h(y) dy
	//         = A l (1-exp(-x/l))
	// To use only the area [0:1] H(1) = 1 must hold, so 
	//    A = 1/[ l(1-exp(-1/l)) ] .
	// Now invert H(x):
	//    H^-1(y) = - l ln[ 1-y/(A l) ] .
	// Now the integral is approximative
	//    < f(x)/h(x) >_h
	// where the ``_h'' means, that random numbers are generated using a
	// uniform number y in [0:1] and then substituting x = H^-1(y) in f/h.
	
	// initialize h and H:
	double l = 0.7 ;
	double A = 1./( l * (1.-exp(-1./l) ) ) ;
	h(0,A,l) ;
	Hinv(0,A,l) ;
	double mean_i = 0 ;
	for( int i = 0 ; i < N ; i++ )
	{
		double x = Hinv( zufall(0,1) ) ;
		mean_i += f(x)/h(x) ;
	}
	mean_i /= N ;

	printf( "# importance sampling: %.6f\n" , mean_i ) ;

	/* 
	for( int i = 0; i < N ; i++ )
		printf( "%f\n" , Hinv( zufall( 0 ,1 ) ) )  ;
		*/
}
