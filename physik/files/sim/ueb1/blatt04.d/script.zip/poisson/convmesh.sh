#!/bin/bash

# check the convergence time for different mesh sizes
# output:
#  [nodes] [iterations] [time]

for N in 10 20 30 40 50 60 70 85 100 115 130 150 175 200
do
	# the inner parenthesis are important -- without the stderr of time cannot be redirected
	iterations=$( ( time -p ./a.out -r -j -N $N ) 2> timeouput | grep Conv | awk '{print $4}')
	duration=$( cat timeouput | grep real | awk '{print $2}' )
	echo $N	$iterations $duration
done

