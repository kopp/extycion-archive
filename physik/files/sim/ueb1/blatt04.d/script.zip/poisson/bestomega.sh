#!/bin/bash

# find the best (losest number of iterations) relaxation parameter for the
# Successive Overrelaxation Scheme

LANG=C

# `seq 1.93 0.0001 1.96`
for w in `seq 1.9395 0.000001 1.9413`
do
	# iter=$( ./a.out -r -s -w $w | grep Conv | awk '{print $4}' )
	iterations=$( ( time -p ./a.out -r -s -w $w ) 2> timeouput | grep Conv | awk '{print $4}')
	duration=$( cat timeouput | grep real | awk '{print $2}' )
	echo $w $iterations $duration
done
