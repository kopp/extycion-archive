#!/bin/bash

# turn all txp*.data files into images and the images into a video in turn
# use `wave.cpp' with the `-m' flag
# 
# usage:
# 1. parameter: name of the video to produce
# 2. parameter: frame rate (default: 0)

if [ -z $1 ]
then
	echo "please enter the name (without .avi etc) of the video to create"
	exit 1 
else
	outputname=$1.mp4
fi
if [ -z $2 ]
then
	framerate=1
else
	framerate=$2
fi


counter=1

for f in $(ls `find . -iname 'txp*.data'`)
do
	X=$(basename $f .data)
	Y=$(printf "img%09d" $counter)
	T=$(echo $X | sed s/txp//)
	cat plotbatch.plt | sed -e s/XXX/$X/g -e s/YYY/$Y/ -e s/TTT/$T/ > currentplot.plt

	gnuplot currentplot.plt
	rm currentplot.plt

	counter=$(($counter+1))
done
echo -- images processed --

ffmpeg -r $framerate -i img%09d.jpg $outputname

# clean up
rm txp*data
rm img*jpg


