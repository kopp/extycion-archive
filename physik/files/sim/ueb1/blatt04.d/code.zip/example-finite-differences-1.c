
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdarg.h>


#define  DX              0.01
#define  Dt              0.1

#define  x_max           1.0
#define  t_max        500000.0

#define  initial_T     473.0
#define  T_at_x0       273.0
#define  T_at_xL       273.0

#define  alpha           1.172e-5

/* There are *two* errors in this code, 
and you have to complete the integration step */ 

int main(int argc, char *argv[])
{

  double r;
  int    nX,nt;
  double *T,*Tnext;

  int    i,j;
  int    flag_write;
  double time;
  FILE* fp;
  char file_profile_name[255];  
  
  /* Compute the parameters of the system */
  
  nX=(int)(x_max/DX);
  nt=(int)(t_max/Dt);

  T     = (double *)  malloc(nX*sizeof(double));  
  Tnext = (double *)  malloc(nX*sizeof(double));  

  
  r = alpha*Dt/DX/DX;
  fprintf(stdout," ratio r = Dt*alpha/(DX)**2 = %le \n", r); 
  fprintf(stdout," nX = %d \n",nX);
  fprintf(stdout," nt = %d \n",nt);
  
  
  /* Introduce the intitial condition */
    T[0]    =  T_at_x0;
    T[nX-1] =  T_at_xL;
     
    for(i=1; i<nX-1; i++){ T[i] =initial_T;}
  
  
  /* Solve the equation for each time step */
    
    flag_write =0;
    time       =0;
    
    for(j=1; j<=nt; j++)
     {
       
        if(j%100==0) fprintf(stdout,".");
       
       /* Let's prepare the values of the next time-step */
       Tnext[0]    =  T_at_x0;
       Tnext[nX-1] =  T_at_xL;
     
       // space integration loop
       for(i=1; i<(nX-1); i++)
        {
          Tnext[i] = T[i] + r * ( T[i+1] - 2. * T[i] + T[i-1] ) ;
	} /* of for i*/
    
    
        /* Let's update the time step and the profile */  
        time+=Dt;   
         
        for(i=0; i<nX; i++)
        {
          T[i] = Tnext[i] ;
	} 
    
        
	/* Let's see if I should write the profile for this time step 
       We use absolute value and compare to half time step to make sure
       we don't mess up for different timestep sizes*/
      	  
        if(fabs(time-1.0)     <= Dt/2) flag_write =1 ;
        if(fabs(time-10.0)    <= Dt/2) flag_write =1 ;
        if(fabs(time-100.0)     <= Dt/2) flag_write =1 ;
        if(fabs(time-1000.0)    <= Dt/2) flag_write =1 ;
        if(fabs(time-10000.0)   <= Dt/2) flag_write =1 ;
        if(fabs(time-100000.0)  <= Dt/2) flag_write =1 ;
        if(fabs(time-500000.0)  <= Dt/2) flag_write =1 ;

	if(flag_write) {
          sprintf(file_profile_name, "profile_T_vs_x_at_time_%lf.dat",time);
          fp=fopen(file_profile_name, "w");
           
	   for(i=0; i<nX; i++)
           {
            fprintf(fp,"%lf %lf\n",i*DX,T[i]);
	   } 
	   fclose(fp);
	   flag_write = 0  ;
	}
    } 
    
   fprintf(stdout," \n Calculations are done\n");
 
 free(T); 
 return 0;
}
