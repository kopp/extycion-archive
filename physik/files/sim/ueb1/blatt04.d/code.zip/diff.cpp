/*
 * diff.cpp
 *
 * Michael Kopp
 *
 * Integrate the diffusion equation
 *
 */


//#include<iostream>
#include<cstdio>



int main()
{

	// // physical parameters // //
	// diffusion constant
	double D = 1.172e-5;
	// length of the rod
	double L = 1.0;


	// // simulation parameters // //
	// number of bins
	int N = 100;
	// binlength
	double dx = L / ( 1.0 * N ) ;
	// timestep
	double dt = 0.1;
	// number of timesteps
	int N_steps = 300000;
	// output every N_output-th step:
	int N_output = N_steps / 150;

	// // derived parameters // //
	const double r = D * dt / dx / dx;


	// // system // //
	// temperature is discretisized using `number of bins' bins:
	double* temp_new = new double[ N ];
	double* temp_old = new double[ N ];


	// // initial conditions // //
	for( int i = 1; i < N-1; i++ )
		temp_old[i] = 473;
	temp_old[0] = 273;
	temp_old[N-1] = 273;
	temp_new[0] = 273;
	temp_new[N-1] = 273;


	// // start the loop // //
	// timeloop
	for( int t = 0; t < N_steps; t++ )
	{
		// loop over the non-fixed bins
		for( int i = 1; i < N-1; i++ )
		{
			temp_new[ i ] = temp_old[ i ] + r * ( temp_old[ i + 1] - 2. * temp_old[ i ] + temp_old[ i - 1 ] ) ;
		}
		// interchange temp_new and temp_old
		/* not necessary:
		double* foo = temp_new;
		temp_new = temp_old;
		temp_old = foo;
		*/
		temp_old = temp_new ;


		// do some output
		// [time t] [x] [T(x,t)]
		if( t % N_output == 0 )
			for( int i = 0; i < N; i++ )
				std::printf( "%.3f \t %.6f \t %.6f \n" , t * dt , i * dx , temp_old[ i ] );
	}


}
