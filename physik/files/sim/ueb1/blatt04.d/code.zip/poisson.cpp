/* * jacobi.cpp
 *
 * Michael Kopp
 *
 * Solve the Poisson equation in 2D using Jacobi Relaxation Method
 *
 * usage:
 *     methods:
 * -j   jacobi relaxation method
 * -g   gauss seidel relaxation method
 * -s   sucessive overrelaxation
 * -w   relaxation parameter \omega   [double]
 *     parameters
 * -L   Length / width of the square  [double]
 * -N   Number of nodes per dimension [int]
 * -e   epsilon: accurancy parameter  [double]
 *     output:
 * def  one 3D gnuplot file
 * -r   only status messages
 * -m   output for movies 
 * -d   steps between two frames      [int]
 * -D   output up to step ...         [int]
 *
 * compile:
 *   g++ -O2 poisson.cpp
 *
 */

#include<cstdio>
using std::printf ;
#include<cmath> // sqrt
using std::sqrt ;
using std::abs ;
#include<cstring> //strcmp
#include<cstdlib> //atof


inline double sqr( const double x ) 
{
	return x * x ;
}

// // global // // 
double L ; // length and width
double h ; // discretisation of position
int N ; // nodes per direction



// source term of poissons equation ``Laplace phi = g''; eg. charges
double g( const int i , const int j )
{
	if( sqrt( sqr( h*i - L/2.) + sqr( h*j - L/2. )  ) <= L/4. ) // whithin circle
		return -1. ;
	else // outside circle
		return 0. ;
	/* example 3
	if( sqr( i - N/2 ) + sqr( j - N/2 ) < sqr( N / 100 ) ) return -1. ;
	return 0. ;
	*/
	/* two bars of opposed charge
	if( (i >= 9) and (i <= 11)  and (j <= 40) and (j>= 10) ) return 100 ;
	if( (i >= 39) and (i <= 41)  and (j <= 40) and (j>= 10) ) return -100 ;
	return 0. ; //else
	*/
}

// discpepancy of old and new solution
double d( double** phi_new , double** phi_old )
{
	double d_max = 0 ; //maximal discrepancy
	double d = 0 ;
	for( int i = 1 ; i < N ; i++ )
	for( int j = 1 ; j < N ; j++ )
	{
		d = abs( phi_new[i][j] - phi_old[i][j] ) ;
		if( d > d_max ) d_max = d ;
	}
	return d_max ;
}

// // movie output
// see wave.cpp
void movieoutput( const bool moviemode , const int stepcounter, const int moviedistance , const int maxstep , double** phi_old )
{
	if( ( moviemode == true ) and ( stepcounter % moviedistance == 0 ) and ( stepcounter <= maxstep ) )
	{
		char* outpuname = new char[16] ;
		std::sprintf( outpuname , "phi%010i.data" , stepcounter ) ;
		FILE * filehandle = std::fopen( outpuname , "w" ) ;
		for( int i = 0 ; i < N+1 ; i++ )
		for( int j = 0 ; j < N+1 ; j++ )
			std::fprintf( filehandle , "%6f \t %6f \t %10e \n" , i*h , j*h , phi_old[i][j] ) ;
		std::fclose( filehandle ) ;
	}
}


int main(int argc , char* argv[])
{
	// // parameters // //
	// size
	L = 1. ;
	// number of nodes in each direction (must be the same in x and y direction since h is valid for both directions)
	N = 100 ;
	// stop condition: if d() < epsilon stop.
	double epsilon = 1e-9 ; 
	// relaxation parameter 
	double omega = 1.9406 ;

	// method to use
	char method = 's' ; // jacobi relaxation method

	// output
	bool silentoutput = false ; // if true output only status messages
	bool moviemode = false ; // if true output gnuplot files for several steps
	int moviedistance = 50 ; // output every `moviedistance'th computation step
	int maxstep = 1e9 ; // output _many_ frames

	// // command line options // //
	for( char** point = argv ; *point ; point++ )	
	{
		// methods
		if( std::strcmp( *point , "-j" ) == 0 ) method = 'j' ;
		if( std::strcmp( *point , "-g" ) == 0 ) method = 'g' ;
		if( std::strcmp( *point , "-s" ) == 0 ) method = 's' ;
		if( std::strcmp( *point , "-w" ) == 0 ) 
			omega = std::atof( *( ++point ) ) ;
		// parameters
		if( std::strcmp( *point , "-L" ) == 0 ) L = std::atof( *( ++point ) ) ;
		if( std::strcmp( *point , "-N" ) == 0 ) N = std::atoi( *( ++point ) ) ;
		if( std::strcmp( *point , "-e" ) == 0 ) epsilon = std::atof( *( ++point ) ) ;
		// ouput
		if( std::strcmp( *point , "-r" ) == 0 ) { silentoutput = true ; moviemode = false ; }
		if( std::strcmp( *point , "-m" ) == 0 ) { moviemode = true ; silentoutput = true  ; }
		if( std::strcmp( *point , "-d" ) == 0 ) moviedistance = std::atoi( *( ++point ) ) ;
		if( std::strcmp( *point , "-D" ) == 0 ) maxstep = std::atoi( *( ++point ) ) ;
	}

	// // derived parameters // //
	// discretisation
	h = L / N ;

	// // print status // //
	// method used
	switch( method ) {
	case 'j' : printf("# Using Jacobi Relaxation Method\n") ; break; 
	case 'g' : printf("# Using Gauss Seidel Relaxation Method\n") ; break; 
	case 's' : printf("# Using Succesive Overrelaxation Method\n") ; break; 
	}
	printf( "# System: length: %5f , No of nodes: %5i , node length: %.6e , precision: %.6e , rela'param: %.6e\n" , L , N , h , epsilon , omega ) ;
	

	// // system // //
	// create two 2D arrays (then holding `0's)
	double** phi_new = new double*[N+1];
	double** phi_old = new double*[N+1];
	for( int i = 0 ; i < N+1 ; i++ )
	{
		phi_new[i] = new double[N+1] ;
		phi_old[i] = new double[N+1] ;
	}


	// // boundary conditions // //
	for( int i = 0 ; i < N+1 ; i++ )
	{
		phi_old[i][0] = 0 ; 
		phi_old[i][N] = 0 ; 
		phi_old[0][i] = 0 ; 
		phi_old[N][i] = 0 ; 
	}


	// // loop // //
	int stepcounter = 0 ; //count how many steps were necessary
	switch( method )
	{
	case 'j' : // jacobi relaxation -------------
		do
		{
			for( int i = 1 ; i < N ; i++ )
				for( int j = 1 ; j < N ; j++ )
					phi_new[i][j] = 0.25 * ( phi_old[i-1][j] + phi_old[i+1][j] + phi_old[i][j-1] + phi_old[i][j+1] - h*h*g(i,j) ) ;
			// switch arrays (no problem since d() is symmetric)
			double** foo = phi_new ;
			phi_new = phi_old ;
			phi_old = foo ;
			stepcounter ++ ;
			movieoutput( moviemode , stepcounter, moviedistance , maxstep , phi_old ) ;
		}
		while( d( phi_new , phi_old ) >= epsilon ) ;
		break ; // -----------------------------------

	case 'g': // gauss seidel relaxation ------
		do
		{
			for( int i = 1 ; i < N ; i++ )
			for( int j = 1 ; j < N ; j++ )
			{
				phi_new[i][j] = phi_old[i][j] ; // copy values from `phi_old' to `phi_new'; `phi_new' will only be used to determine convergence
				phi_old[i][j] = 0.25 * ( phi_old[i-1][j] + phi_old[i+1][j] + phi_old[i][j-1] + phi_old[i][j+1] - h*h*g(i,j) ) ;
			}
			stepcounter ++ ;
			movieoutput( moviemode , stepcounter, moviedistance , maxstep , phi_old ) ;
		}
		while( d( phi_new , phi_old ) >= epsilon ) ;
		break; // -------------------------
	case 's': // sucessive overrelaxation  ----------------
		do
		{
			double R = 0 ; // residual parameter 	
			for( int i = 1 ; i < N ; i++ )
			for( int j = 1 ; j < N ; j++ )
			{
				phi_new[i][j] = phi_old[i][j] ; // copy values from `phi_old' to `phi_new'; `phi_new' will only be used to determine convergence
				R = 0.25 * ( phi_old[i-1][j] + phi_old[i+1][j] + phi_old[i][j-1] + phi_old[i][j+1] - h*h*g(i,j) ) ;
				phi_old[i][j] = (1-omega) * phi_old[i][j] + omega * R ;
			}
			stepcounter ++ ;
			movieoutput( moviemode , stepcounter, moviedistance , maxstep , phi_old ) ;
		}
		while( d( phi_new , phi_old ) >= epsilon ) ;
		break; // -------------------------------------


	}


	// status
	printf( "# Converged after %7i iterations\n" , stepcounter ) ;

	// // final output // //
	if( silentoutput == false ) 
	{
		for( int i = 0 ; i < N+1 ; i++ )
		for( int j = 0 ; j < N+1 ; j++ )
			printf( "%6f \t %6f \t %10e \n" , i*h , j*h , phi_old[i][j] ) ;
	}

}
	
