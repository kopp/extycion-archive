/* * analytical.cpp
 *
 * Michael Kopp
 *
 * print an approximation to the analytical problem of the diffusion equation in the same style as `diff.cpp' does
 *
 * 
 */

//#include<iostream>
#include<cstdio>
#include<cmath>

using std::sin;
using std::exp;

inline double sqr( const double x )
{
	return x * x ; 
}
inline double abs( const double x )
{
	return ( x >= 0 ?  x  : -x ) ;
}


int main()
{
	// // precision // //
	// when to stop the `infinite' summation:
	// if the current summand is the `delta'th part of the previous one
	// IMPORTANT: currently not in use!
	double delta = .9 ;
	// if the current summand is smaller than epsilon -- stop
	double epsilon = 1e-10 ;
	
	
	// // boundaries // // 
	// these parameters are identical to the ones from `diff.cpp'
	// diffusion constant
	double D = 1.172e-5;
	// length of the rod
	double L = 1.0;
	// number of bins
	int N = 100;
	// timestep
	double dt = 0.1;
	// number of timesteps
	int N_steps = 300000;
	// output every N_output-th step:
	int N_output = N_steps / 150;
	
	// // derive parameters // //
	// don't touch //
	const double x_stepwidth = L / ( 1. * N ) ;
	const double x_max = L ;
	const double t_stepwidth = dt * .25 * N_output ;  // do 4 times more output
	const double t_max = dt * N_steps ;


	// loops
	for( double x = 0; x <= x_max; x += x_stepwidth ) 
		for( double t = 0; t <= t_max; t += t_stepwidth )
		{
			// // compute the series
			double reihe = 0;  // current value of the series
			double summand1 = 0; // value to add in this certain step
			double summand2 = 0; // value to add in this certain step
			// instead of 2 use n addends -- they are compared to figure whether the series is `done'
			int k = 0 ; // counter -- k = 0,1,...,infty
			do {
				summand1 = ( sin( (2*k+1)*M_PI*x/L ) * exp( -D*t*sqr( (2*k+1)*M_PI/L ) ) ) / (2*k+1) ;
				reihe += summand1 ;
				k++ ;
				summand2 = ( sin( (2*k+1)*M_PI*x/L ) * exp( -D*t*sqr( (2*k+1)*M_PI/L ) ) ) / (2*k+1) ;
				reihe += summand2 ;
				k++ ;
			}
			while( 
				   ( k <= 50 ) // max 50 iterations
				&& ( abs( summand1 / reihe ) >= epsilon )   // addends must have at least some `size'
				&& ( abs( summand2 / reihe ) >= epsilon ) 
				// && ( abs( summand2 / summand1 ) >= delta )  // 
			     ) ;
			

			// // temperature
			double T = 273. + 4. * (473 - 273 ) / M_PI * reihe ;
			
			// // output
			// [time] [x] [T(x,t)]
			std::printf( "%.3f \t %.6f \t %.6f \n" , t , x , T );
			// debug
			// std::printf( "# %5d runs at (t,x) = ( %9.6f , %9.6f ) -- partialsumme = %9.6e, summand1 = %9.6e, summand2 = %9.6e; quot = %9.6f. \n" , k , t , x , reihe , summand1 , summand2 , summand1/summand2 ) ;
		}
}



